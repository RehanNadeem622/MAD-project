import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dine_in/Controllers/cart_controller.dart';
import 'package:dine_in/Views/Utils/Styles/text_styles.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  CartController cartController = Get.put(CartController());
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  // User? user = FirebaseAuth.instance.currentUser;
  String uid = '';

  getUser() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      return;
    }
    uid = user.uid;
  }

  Stream<QuerySnapshot> getCartStream() {
    getUser();
    return _firestore
        .collection('carts')
        .where('userId', isEqualTo: uid)
        .snapshots();
  }

  Future<DocumentSnapshot> getCart() async {
    final snapshot = await _firestore
        .collection('carts')
        .where('userId', isEqualTo: uid)
        .get();
    if (snapshot.docs.isEmpty) {
      return snapshot.docs.first;
    }
    return snapshot.docs.first;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "My Cart",
          style: CustomTextStyles.appBarStyle,
        ),
      ),
    );
  }
}
